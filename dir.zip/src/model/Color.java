package model;

/**
 * Color is an enumeration which contains Red,Green and Blue components.
 */
public enum Color {
  RED,
  BLUE,
  GREEN
}
