package model;

/**
 * Channel is an enumeration which contains Value, Intensity and Luma.
 */
public enum Channel {
  VALUE,
  INTENSITY,
  LUMA
}
